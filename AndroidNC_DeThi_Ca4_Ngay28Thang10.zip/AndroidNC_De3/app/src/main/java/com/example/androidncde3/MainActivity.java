package com.example.androidncde3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {
    /*
    Thời gian làm bài: 50 phút
    ------
    Một số qui định khi làm bài
     -tên các control chứa mã sinh viên, tên các biến chứa mã sinh viên,
     -tên các file code chứa mã sinh viên, tên package chứa mã sinh viên.
     VD: PH0001MainActivity.java; ph0001_main_activity.xml.
     -Nếu không đổi tên hết, tối đa 8 điểm. Nếu không làm xong, đúng, đầy đủ 100% yêu cầu trong 50 phút, tối đa 8 điểm.
     */
    /*
    Yêu cầu về CSDL ở câu 2:-------------------------------------------------
    Bảng TheLoai (MaTL,TenTL)
    Bang SanPham(MaSP, TenSP, SoLuongNhap,NgayNhap,DonGiaNhap)
    Bang HoaDon (MaHD, NgayBan, TenKhachHang)
    Bang HoaDonChiTiet (MaHDCT, MaSP, GiaBan)
    Các trường dữ liệu các bạn có thể tùy chọn
    */
    /*
    ----------------------------------------------
    Cau 3: Tính tổng số lượng hàng nhập theo từng sản phẩm trong 1 tháng của năm, với tháng nhập vào từ bàn phím,
     ( ví dụ: Tổng số lượng SP A trong tháng 1/2021: 20, Tổng số lượng SP B trong tháng 2/2020: 10 )(2đ)
    Cau 4: Tổng số lượng sản phẩm bán được trong trong các tháng chẵn của 1 năm theo từng thể loại
    (nhập vào năm 2020 thì phải tính được tổng số lượng bán được của tháng 2,4,6,8,10,12)
    (ví dụ: Tổng số lượng bán được của Thể loại A trong các tháng chẵn năm 2020 là 50; Thể loại B: 70)(2đ)
    * */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}